Extended Pickup Icons Range v2.4.0
=======================================

See samples, supplies, mission items and vehicles from farther away, marked with the
game's own icons.

What gets a marker (default distance):
- Samples (50 m): common, rare and super samples, sample containers, Terminid eggs.
- Supplies (25 m): ammo boxes, grenade boxes, stims and resupply pod crates.
- Mission items (50 m): SSSDs, data drives, black boxes, larva containers (in sky blue),
  launch codes, keycards, video cameras, artillery shells, warheads and other things you carry.
- Mission objectives (50 m): drop-off points, cargo containers, valves and cranks.
- Hellbombs (100 m): the hellbombs lying about the map that blow up when shot, in red.
- Vehicles (100 m): exosuits, FRVs and tanks, in sky blue; out of view, at the screen's edge
  with an arrow.

Vehicle and hellbomb markers show their distance. Markers sit where the game shows its own
icon, get smaller farther away (supply markers fainter too), are sized to your screen
resolution, follow the game's camera (scopes too), and hide while a menu is open; on your
ship mission markers are off. Items someone is
carrying, picked-up launch codes and keycards, hellbombs that blew up, destroyed vehicles
and the vehicle you or a teammate are driving get no marker. Items close enough
for the game to show its own icon get none either: samples within 9 m (Terminid eggs and
Automaton super samples 20 m, sample containers 15 m) and ammo and grenade boxes within
4 m. Stims have no icon of the game's and keep theirs.

Settings: press F9 in the game (Chef Shared Loader's options menu) and pick Extended
Pickup Icons Range: turn each kind on or off and set its distance, fade supplies far away,
show or hide the distance above vehicles and hellbombs, keep markers on up close, and change their size far away
and opacity.

Requires Chef Shared Loader 1.2.0 or newer (Nexus mod 17760). Give it the highest priority
in your mod manager (in Arsenal, by default, the bottom of the list).

Good to know:
- Valves and cranks stay marked after you turn them.
- At most the 40 nearest markers are drawn at once.
