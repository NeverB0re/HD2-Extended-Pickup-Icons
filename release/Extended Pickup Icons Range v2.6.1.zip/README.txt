Extended Pickup Icons Range v2.6.1
=======================================

See samples, supplies, mission items and vehicles from farther away, using the game's icons.

2.6.1: improved resupply-crate rendering/fading, reduced repeated unit/drawing work,
important-marker retention and Chef-managed support logging. Settings from 2.6.0 are kept.

Requires Chef Shared Loader 1.4.0 or newer (Nexus mod 17760); the latest is recommended.
Give Chef the highest priority in your mod manager. This is a Chef addon. Other loaders
must provide compatible Chef addon support; standalone compatibility is not guaranteed.
Remove the previous version before importing and deploying this ZIP. Do not run both.

SETTINGS: preferences from 2.6.0 are preserved. Only updates from versions older than
2.6.0 start with default settings after the native Chef backend change. Press F9 and select
Extended Pickup Icons Range. No separate Mod Options Menu mod is required.

What gets a marker (default distance):
- Samples (50 m): common, rare, super, sample containers and Terminid eggs.
- Supplies (25 m): ammo, grenades, stims and resupply crates.
- Mission items (50 m): SSSDs/data, black boxes, larva containers, launch codes/keycards,
  cameras, briefcases, chemical containers, artillery shells, warheads and fusion batteries.
- Objective interactions (50 m): drop-off points, cargo containers, valves and cranks.
- Hellbombs (100 m): damaged map bombs and fixed mission call-ins. Portable backpacks excluded.
- Vehicles (100 m): exosuits, FRV variants and tanks. Off-screen markers have direction arrows.
- Your last death (500 m): a red skull, also with an off-screen arrow, cleared within 4 m.

F9 settings use folded categories: Samples, Supplies, Mission items and objectives,
Hellbombs, Vehicles, Death marker and Common appearance. Open a category to configure
individual type visibility and distance. Master switches keep individual choices intact.
Changing "Set all ... distances (m)" overwrites the type distances in that category.
Sample/supply fading is in its category. Common settings include distance text, opacity,
size at range and hiding our markers where vanilla icons appear. A warning toggle is in
Hellbombs. Older Chef interfaces without headings display the same native options flat;
loaders without the native option API retain only the previous category-level controls.

Mission Hellbomb warning:
- Observes the bomb's activation, rather than local button input.
- Large 15:00 -> 00:00 display in seconds:hundredths, with an accelerating yellow-to-red pulse.
- First observed already active: ARMED, without a guessed new countdown.
- This is a local estimate, not a replicated explosion deadline or hundredth-second accuracy.
  Damage may destroy the bomb earlier. Zero keeps warning until the marker disappears.
- Only fixed mission Hellbombs on the verified game build have this warning. Other builds
  retain ordinary markers. Damaged map bombs and portable backpacks have no countdown.

Behavior and limits:
- At most 40 markers are drawn: your last death first, then vehicles/Hellbombs, then the
  nearest other markers. Markers scale with distance/resolution, follow
  the camera and scopes, and hide in menus. Mission markers are hidden on the ship.
- Near vanilla icons, our markers normally hide: samples 9 m, eggs/Automaton super samples
  20 m, sample containers 15 m, ammo/grenades 4 m. Stims keep their marker, solid within 5 m.
- Carried/delivered items and destroyed vehicles use guarded position/geometry heuristics;
  detection can be imperfect. Deleted units and confirmed vanished geometry are suppressed.
  There is no universal height cutoff for underground targets. Valves/cranks stay marked
  after use. Occupied/moving vehicles are suppressed using nearby-player observations.
- On supported builds, local health reaching zero confirms death. The position is frozen
  from the previously linked own sample container, else a fresh last-known position; it
  does not follow the corpse or container afterward. Missing/ambiguous data is not death.
  Unknown builds retain the earlier camera-based death method. Only the last death is shown.
- Experimental position/timing/statistics logs are removed. Basic support information and
  errors remain in ExtendedPickupIcons.log in Chef's log folder (launches follow one another,
  so one that crashed stays readable). No debug panel, calibration mode or test files are shipped.
