Extended Pickup Icons Range v2.1.0
=======================================

See samples, supplies, mission items and vehicles from farther away, marked with the
game's own icons.

What gets a marker (default distance):
- Samples (40 m): common, rare and super samples, sample containers, Terminid eggs.
- Supplies (25 m): ammo boxes, grenade boxes, stims and resupply pod crates.
- Mission items (40 m): SSSDs, data drives, black boxes, larva containers, launch codes,
  keycards, video cameras and more.
- Shells, warheads and batteries you carry (25 m).
- Drop-off points and cargo containers (40 m), and valves and cranks you turn (40 m).
- Vehicles (100 m): exosuits, FRVs and tanks.

Markers get a little smaller farther away and hide while a menu is open. Items someone is
carrying, and the vehicle you or a teammate are driving, get no marker. Items close enough
for the game to show its own icon get none either: samples within 9 m (Terminid eggs and
Automaton super samples 20 m, sample containers 15 m) and supplies within 4 m.

Settings: turn each kind on or off and set its distance with HD2 Mod Setting GUI
(Nexus mod 17756). It can also keep markers on up close, and change their smallest size,
opacity (optionally fading with distance) and the position of sample and supply markers.
Without it, the defaults above are used.

Requires Boot Mod Loader (Nexus mod 17754). In your mod manager's load order, Boot Mod
Loader must be above this mod (Arsenal may put it below by default: move it up).

Good to know:
- Drop-off points and valves stay marked after you use them.
- Destroyed exosuits and FRVs lose their marker. Destroyed tanks and supply FRVs keep it
  until the wreck disappears from the map.
- While aiming down sights, markers may sit slightly off the item.
